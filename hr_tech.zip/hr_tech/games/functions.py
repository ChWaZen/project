import itertools
import pandas as pd
import random
import numpy as np
from .models import tester_bomb_score_db, tester_set_score_db, tester_cat_score_db, tester_numerosity_score_db

def check_numbers(numbers):
    """
    Check if all numbers in the list are either the same or all different.
    Returns 1 if true, otherwise returns 0.
    """
    unique_numbers = set(numbers)
    return 1 if len(unique_numbers) == 1 or len(unique_numbers) == len(numbers) else 0


# Generating tuples with values 0, 1, 2 for x1, x2, x3, x4
tuples = list(itertools.product([0, 1, 2], repeat=4))
all_tuples = pd.DataFrame(tuples, columns=['x1', 'x2', 'x3', 'x4'])


def get_sets():
    while True:
        random_selection = random.sample(range(81), 9)
        combinations_set = list(itertools.combinations(set(random_selection), 3))

        result = [all_tuples.loc[row,].apply(check_numbers).sum() == 4 for row in combinations_set]

        if sum(result) == 1:
            answer = pd.DataFrame(combinations_set).loc[result].values.tolist()
            return random_selection, answer


##################################################################
def generate_complex_encoding_map():
    charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='
    encoding_map = {}
    # 线性同余生成器参数
    a = 1664525
    c = 1013904223
    m = 2 ** 32
    seed = [123456789]  # 使用列表封装seed以在闭包内修改

    # 生成伪随机数
    def pseudo_random():
        seed[0] = (a * seed[0] + c) % m
        return seed[0] / m

    for i in range(0, 65):
        # 生成伪随机索引
        index = int(pseudo_random() * len(charset))
        # 确保映射是唯一的
        while charset[index] in encoding_map.values():
            index = int(pseudo_random() * len(charset))
        encoding_map[i] = charset[index]

    return encoding_map

def add(x, y):
    return x + y

def sub(x, y):
    return x - y

def product(x, y):
    return x * y

def div(x, y):
    if y != 0:
        return x / y
    else:
        return 0

# 创建一个运算符到函数的映射
operator_functions = {
    'add': add,
    'sub': sub,
    'product': product,
    'div': div
}



operator_sym = {
    'add': '+',
    'sub': '-',
    'product': '×',
    'div': '÷',
}

###########################################################################################
# 可以被整除的SET
all_pairs = {
    'div': [(j, i, int(j / i)) for i in range(2, 100) for j in range(i + 1, 100) if j % i == 0],
    'product': [(i, j, j * i) for i in range(2, 100) for j in range(i + 1, 100) if i * j < 100],
    'add': [(i, j, j + i) for i in range(2, 100) for j in range(i + 1, 100) if i + j < 100],
    'sub': [(i, j, i - j) for i in range(2, 100) for j in range(2, 100) if i - j > 0]
    }

operator = ['div', 'product', 'add', 'sub']

def distribute_choices():
    ran_operator = random.choice(operator)
    a, b, c = random.choice(all_pairs[ran_operator])
    random_numbers = random.sample([x for x in range(2, 100) if x not in (a, b, c)], 7)

    # 隨機抽掉兩個數字
    chosen = random.choice(['a', 'b', 'c'])

    if chosen == 'a':
        random_numbers.append(b)
        random_numbers.append(c)
        b, c = '', ''
        blanks = [1, 2]
    elif chosen == 'b':
        random_numbers.append(a)
        random_numbers.append(c)
        a, c = '', ''
        blanks = [0, 2]
    else:
        random_numbers.append(a)
        random_numbers.append(b)
        a, b = '', ''
        blanks = [0, 1]

    random.shuffle(random_numbers)

    return a, b, c, ran_operator, random_numbers, operator_sym[ran_operator], blanks

##################################################################################################

def generate_matrix():
    while True:
        # 創建一個長度為16的一維全1數組
        matrix = np.ones(16, dtype=int)

        # 隨機選擇四個位置設為0
        zero_positions = np.random.choice(16, 4, replace=False)
        matrix[zero_positions] = -1

        # 將一維數組重塑為4x4的二維矩陣
        matrix = matrix.reshape((4, 4))

        a = matrix * -1
        b = a.T

        options = [0] * 4
        rot_times = np.random.randint(1, 4)
        answer = options[0] = np.rot90(a, k=rot_times)
        options[1: 4] = [np.rot90(b, k=i) for i in [0, 1, 2, 3] if i != rot_times]

        if (not np.array_equal(a, b)) & (not any(np.array_equal(answer, option) for option in options[1: 4])):
            break

    np.random.shuffle(options)

    return matrix, answer, options

######################################################################################


def standardized(db):
    # 检查数据库是否为空
    if db.objects.count() == 0:
        return pd.DataFrame(columns=['tester_code', 'standardized_score'])

    df = pd.DataFrame(list(db.objects.all().values('tester_code', 'score')))
    if df.empty:
        return df.reindex(columns=['tester_code', 'standardized_score'])

    max_score = df['score'].max()
    min_score = df['score'].min()
    df['standardized_score'] = round((df['score'] - min_score) / (max_score - min_score) * 100, 2)
    return df[['tester_code', 'standardized_score']]


def full_join_dfs(df1, df2, key, suffixes):
    return pd.merge(df1, df2, on=key, how='outer', suffixes=suffixes)

def count_scores():
    bomb_score = standardized(tester_bomb_score_db)
    # set_score = standardized(tester_set_score_db)
    cat_score = standardized(tester_cat_score_db)
    numerosity_score = standardized(tester_numerosity_score_db)

    # 进行全外连接

    df_final = full_join_dfs(bomb_score,numerosity_score , 'tester_code', ('', '_2'))
    df_final = full_join_dfs(df_final,cat_score , 'tester_code', ('', '_3'))
    #df_final = full_join_dfs(df_final, set_score, 'tester_code', ('_bomb', '_set'))

    # 计算所有standardized_score的总和，处理NA
    df_final['total_standardized_score'] = df_final.filter(regex='standardized_score').sum(axis=1, skipna=False)

    # 对得分进行降序排序
    df_final = df_final.sort_values(by='total_standardized_score', ascending=False)
    df_final.reset_index(drop=True, inplace=True)
    df_final.index = df_final.index + 1
    return df_final


