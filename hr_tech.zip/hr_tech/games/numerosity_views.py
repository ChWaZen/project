from django.shortcuts import render, redirect
from .models import tester_numerosity_score_db,tester_char_db
from .functions import operator_functions, distribute_choices


def introduction(request):
    tester_code = request.session.get('tester_code', None)
    request.session.pop('numerosity_completed', None)
    if not tester_code:
        # 如果 tester_code 不存在或者为 None，可以在此处进行处理，例如重定向到登录页面
        return redirect('login_page')  # 假设登录页面的 URL 名称为 login_page

    tester = tester_char_db.objects.filter(tester_code=tester_code).first()
    if not tester:
        # 如果找不到对应的 tester，可以在此处进行处理，例如显示错误页面
        return render(request, 'error.html', {'message': 'Tester not found'})

    if request.method == 'POST':
        return redirect('game_numerosity_test_page')

    tester_scores = tester_numerosity_score_db.objects.filter(tester_code=tester_code)
    if tester_scores.exists():
        return redirect('game_numerosity_result_page')

    return render(request, 'games/numerosity/introduction.html')


def test_page(request):
    tester_code = request.session.get('tester_code', None)
    if not tester_code:
        return redirect('login_page')
    if 'numerosity_completed' in request.session:
        return redirect('game_numerosity_result_page')  # 如果测试已完成，则重定向到结果页面

    score_entry, created = tester_numerosity_score_db.objects.get_or_create(tester_code=tester_code)

    if request.method == "POST":
        action_button = request.POST.get('action_button')
        score_entry.answered_count += 1
        current_question = request.session.get('current_question')

        if action_button == 'submit':
            all_value = request.POST.get('AllValue')
            if '＿' not in all_value:
                # if current_question and all_value == current_question['all_value']:
                answers = all_value.split(',')
                a1, b1, c1 = map(int, answers[:3])
                if operator_functions[answers[3]](a1, b1) == c1:
                    score_entry.correct += 1
            # Generate new question regardless of the current question's correctness
            a, b, c, ran_operator, random_numbers, operator_sym, blanks = distribute_choices()
            current_question = {
                "a": a, "b": b, "c": c,
                "ran_operator": ran_operator,
                "random_numbers": random_numbers,
                "operator_sym": operator_sym,
                "blanks": blanks,
                "all_value": ','.join([str(a), str(b), str(c), ran_operator])
            }
            request.session['current_question'] = current_question

        elif action_button == 'skip':
            score_entry.skipped_count += 1
            # Generate new question when skipped
            a, b, c, ran_operator, random_numbers, operator_sym, blanks = distribute_choices()
            current_question = {
                "a": a, "b": b, "c": c,
                "ran_operator": ran_operator,
                "random_numbers": random_numbers,
                "operator_sym": operator_sym,
                "blanks": blanks,
                "all_value": ','.join([str(a), str(b), str(c), ran_operator])
            }
            request.session['current_question'] = current_question

        score_entry.save()
        # Redirect to avoid form re-submission issues
        return redirect('game_numerosity_test_page')

    else:
        # Check for current question in session, generate if none exists
        if 'current_question' not in request.session:
            a, b, c, ran_operator, random_numbers, operator_sym, blanks = distribute_choices()
            current_question = {
                "a": a, "b": b, "c": c,
                "ran_operator": ran_operator,
                "random_numbers": random_numbers,
                "operator_sym": operator_sym,
                "blanks": blanks,
                "all_value": ','.join([str(a), str(b), str(c), ran_operator])
            }
            request.session['current_question'] = current_question

    current_question = request.session.get('current_question')
    context = {
        "a": current_question['a'],
        "b": current_question['b'],
        "c": current_question['c'],
        "blanks": current_question['blanks'],
        "operator_sym": current_question['operator_sym'],
        "ran_operator": current_question['ran_operator'],
        "random_numbers": current_question['random_numbers'],
    }
    return render(request, 'games/numerosity/test_page.html', context)


def result_page(request):
    request.session['numerosity_completed'] = True
    tester_code = request.session.get('tester_code', None)
    numerosity_score_entry, created = tester_numerosity_score_db.objects.get_or_create(
        tester_code=tester_code,
    )
    numerosity_score_entry.score = numerosity_score_entry.correct * 3 - numerosity_score_entry.skipped_count * 0.5 - (
            numerosity_score_entry.answered_count - numerosity_score_entry.correct - numerosity_score_entry.skipped_count)
    numerosity_score_entry.save()

    if request.method == "POST":
        confidence_value = request.POST.get('performance', 0)
        numerosity_score_entry.confidence_score = confidence_value
        numerosity_score_entry.save()
        return redirect('game_select')
    context = {
        'score': numerosity_score_entry.score,
    }
    return render(request, 'games/numerosity/result.html', context)
