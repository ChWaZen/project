import numpy as np
from django.shortcuts import render, redirect
from .models import tester_cat_score_db,tester_char_db
from .functions import generate_matrix


def introduction(request):
    tester_code = request.session.get('tester_code', None)
    request.session.pop('cat_completed', None)
    if not tester_code:
        # 如果 tester_code 不存在或者为 None，可以在此处进行处理，例如重定向到登录页面
        return redirect('login_page')  # 假设登录页面的 URL 名称为 login_page

    tester = tester_char_db.objects.filter(tester_code=tester_code).first()
    if not tester:
        # 如果找不到对应的 tester，可以在此处进行处理，例如显示错误页面
        return render(request, 'error.html', {'message': 'Tester not found'})

    if request.method == 'POST':
        return redirect('game_cat_test_page')

    tester_scores = tester_cat_score_db.objects.filter(tester_code=tester_code)
    if tester_scores.exists() and tester_scores.first():
        return redirect('game_cat_result_page')

    return render(request,'games/cat/introduction.html')


def test_page(request):
    tester_code = request.session.get('tester_code', None)
    if not tester_code:
        # Redirect to the login page if tester_code does not exist
        return redirect('login_page')

    if 'cat_completed' in request.session:
        return redirect('game_cat_result_page')  # 如果测试已完成，则重定向到结果页面


    cat_score_entry, created = tester_cat_score_db.objects.get_or_create(tester_code=tester_code)

    if request.method == "POST":
        cat_score_entry.answered_count += 1
        action_button = request.POST.get('action_button')
        print(action_button)
        if action_button == "submit":
            chosen = int(request.POST.get('chosen'))
            if (request.session['answer'] == request.session['options'][chosen]) and (chosen >= 0):
                cat_score_entry.correct += 1
        else:
            cat_score_entry.skipped_count += 1
        cat_score_entry.save()

        # Always generate new matrix, answer, and options after POST
        matrix, answer, options = generate_matrix()
        request.session['matrix'] = matrix.tolist()
        request.session['answer'] = answer.tolist()
        request.session['options'] = [option.tolist() for option in options]

    # Check if matrix, answer, and options already exist in the session
    elif 'matrix' in request.session and 'answer' in request.session and 'options' in request.session:
        matrix = request.session['matrix']
        answer = request.session['answer']
        options = request.session['options']
    else:
        # Generate new matrix, answer, and options if not in session
        matrix, answer, options = generate_matrix()
        request.session['matrix'] = matrix.tolist()
        request.session['answer'] = answer.tolist()
        request.session['options'] = [option.tolist() for option in options]

    indexed_options = [{'index': i, 'option': option} for i, option in enumerate(options)]
    context = {
        'matrix': matrix,
        'options': indexed_options
    }
    return render(request, 'games/cat/test_page.html', context)


def result_page(request):
    request.session['cat_completed'] = True
    tester_code = request.session.get('tester_code', None)
    cat_score_entry, created = tester_cat_score_db.objects.get_or_create(
        tester_code=tester_code,
    )

    cat_score_entry.score = cat_score_entry.correct * 3 - cat_score_entry.skipped_count * 0.5 - (
            cat_score_entry.answered_count - cat_score_entry.correct - cat_score_entry.skipped_count) * 1
    cat_score_entry.save()

    if request.method == "POST":
        confidence_value = request.POST.get('performance', 0)
        cat_score_entry.confidence_score = confidence_value
        cat_score_entry.save()
        return redirect('game_select')
    context = {
        'score': cat_score_entry.score,
    }
    return render(request, 'games/cat/result.html', context)