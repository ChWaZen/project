from django.shortcuts import render, redirect
from .models import tester_bomb_score_db
from .functions import generate_complex_encoding_map
import random

def introduction(request):
    tester_code = request.session.get('tester_code', None)
    request.session.pop('bomb_completed', None)
    tester_scores = tester_bomb_score_db.objects.filter(tester_code=tester_code)
    if tester_scores.exists():
        return redirect('game_bomb_result_page')
    return render(request, 'games/bomb_risk_test/introduction.html')


complex_encoding_map = generate_complex_encoding_map()


def test_page(request):
    tester_code = request.session.get('tester_code', None)

    if tester_code is None:
        return redirect('login_page')
    if 'bomb_completed' in request.session:
        return redirect('game_bomb_result_page')  # 如果测试已完成，则重定向到结果页面

    bomb_score_entry, created = tester_bomb_score_db.objects.get_or_create(
        tester_code=tester_code,
    )

    # 从 session 获取当前轮次，如果不存在则从数据库读取
    current_round = request.session.get('current_round', bomb_score_entry.current_round)

    if request.method == "POST":
        score = request.POST.get('boxes_collected')
        score_field_name = f'score_{current_round}'

        # 更新得分和轮次，仅在提交得分时
        if 'submit_score' in request.POST:  # 确保检查的是正确的表单提交按钮
            current_round += 1
            request.session['current_round'] = current_round  # 更新 session 中的轮次

            tester_bomb_score_db.objects.update_or_create(
                tester_code=tester_code,
                defaults={
                    score_field_name: score,
                    'current_round': current_round,
                }
            )

    if current_round == 0:
        bomb_exp_time = random.randint(1, 64) - 2
    elif current_round >= 4:
        return redirect('game_bomb_result_page')
    else:
        bomb_field = f'bomb_{current_round}'
        bomb_exp_time = getattr(bomb_score_entry, bomb_field, 0)

    bomb_exp_time_encoded = complex_encoding_map.get(bomb_exp_time, bomb_exp_time)  # 安全处理

    context = {
        'current_round': current_round,
        'range_8': range(8),
        'bomb_exp_time_encoded': bomb_exp_time_encoded,
        'bomb_exp_time': bomb_exp_time + 1,
        'score_1': getattr(bomb_score_entry, 'score_1', 0),
        'score_2': getattr(bomb_score_entry, 'score_2', 0),
        'score_3': getattr(bomb_score_entry, 'score_3', 0),
    }
    return render(request, 'games/bomb_risk_test/test_page.html', context)


def result_page(request):
    request.session['bomb_completed'] = True
    tester_code = request.session.get('tester_code', None)
    bomb_score_entry, created = tester_bomb_score_db.objects.get_or_create(
        tester_code=tester_code,
    )
    bomb_score_entry.score = bomb_score_entry.score_1 + bomb_score_entry.score_2 + bomb_score_entry.score_3
    bomb_score_entry.save()
    if request.method == "POST":
        confidence_value = request.POST.get('performance', 0)
        bomb_score_entry.confidence_score = confidence_value
        bomb_score_entry.save()
        return redirect('game_select')

    context = {
        'score_1': bomb_score_entry.score_1,
        'score_2': bomb_score_entry.score_2,
        'score_3': bomb_score_entry.score_3,
        #'score_4': bomb_score_entry.score_4,
        #'score_5': bomb_score_entry.score_5,
    }
    return render(request, 'games/bomb_risk_test/result.html', context)